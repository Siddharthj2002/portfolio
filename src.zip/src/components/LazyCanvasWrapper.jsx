// LazyCanvasWrapper.jsx
import React from "react";
import { useInView } from "react-intersection-observer";

const LazyCanvasWrapper = ({ children }) => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  });

  return (
    <div ref={ref} className="absolute w-full h-full top-0 left-0 z-[-1]">
      {inView ? children : null}
    </div>
  );
};

export default LazyCanvasWrapper;
