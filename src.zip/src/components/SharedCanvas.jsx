// components/SharedCanvas.jsx
import React, { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Preload } from "@react-three/drei";

import CanvasLoader from "./Loader";
import Earth from "./canvas/Earth";
import Ball from "./canvas/Ball";
import Computers from "./canvas/Computers";
import Stars from "./canvas/Stars";
import { technologies } from "../constants";

const SceneSelector = ({ section, icon, isMobile }) => {
  switch (section) {
    case "earth":
      return (
        <>
          <OrbitControls
            autoRotate
            enableZoom={false}
            maxPolarAngle={Math.PI / 2}
            minPolarAngle={Math.PI / 2}
          />
          <Earth />
        </>
      );
    case "computer":
      return (
        <>
          <OrbitControls
            enableZoom={false}
            maxPolarAngle={Math.PI / 2}
            minPolarAngle={Math.PI / 2}
          />
          <Computers isMobile={isMobile} />
        </>
      );
    case "ball":
      return (
        <>
          <OrbitControls enableZoom={false} />
          {technologies.map((tech, index) => (
            <group key={tech.name} position={[index * 3 - 6, 0, 0]}>
              <Ball imgUrl={tech.icon} />
            </group>
          ))}
        </>
      );
    case "stars":
      return <Stars count={5000} shape="box" />;
    default:
      return null;
  }
};

const SharedCanvas = ({ section, icon, isMobile }) => {
  return (
    <Canvas
      frameloop="demand"
      dpr={[1, 2]}
      camera={{ position: [0, 0, 5], fov: 45 }}
      gl={{ preserveDrawingBuffer: true }}
    >
      <Suspense fallback={<CanvasLoader />}>
        <SceneSelector section={section} icon={icon} isMobile={isMobile} />
        <Preload all />
      </Suspense>
    </Canvas>
  );
};

export default SharedCanvas;
