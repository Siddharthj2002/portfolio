// import { BrowserRouter } from "react-router-dom";

// import { About, Contact, Experience, Feedbacks, Hero, Navbar, Tech, Works, StarsCanvas } from "./components";

// const App = () => {
//   return (
//     <BrowserRouter basename={import.meta.env.BASE_URL}>
//       <div className='relative z-0 bg-primary'>
//         <div className='bg-hero-pattern bg-cover bg-no-repeat bg-center'>
//           <Navbar />
//           <Hero />
//         </div>
//         <About />
//         <Experience />
//         <Tech />
//         <Works />
//         {/* <Feedbacks /> */}
//         <div className='relative z-0'>
//           <Contact />
//           <StarsCanvas />
//         </div>
//       </div>
//     </BrowserRouter>
//   );
// }

// export default App;

// App.jsx
import { useState, useEffect } from "react";
import { BrowserRouter } from "react-router-dom";

import { About, Contact, Experience, Feedbacks, Hero, Navbar, Tech, Works } from "./components";
import SharedCanvas from "./components/SharedCanvas";

const App = () => {
  const [currentScene, setCurrentScene] = useState("stars"); // default
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(max-width: 500px)");
    setIsMobile(mediaQuery.matches);
    const handler = (e) => setIsMobile(e.matches);
    mediaQuery.addEventListener("change", handler);
    return () => mediaQuery.removeEventListener("change", handler);
  }, []);

  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <div className='relative z-0 bg-primary'>
        <div className='bg-hero-pattern bg-cover bg-no-repeat bg-center'>
          <Navbar />
          <Hero setCurrentScene={setCurrentScene} />
        </div>
        <About setCurrentScene={setCurrentScene} />
        <Experience setCurrentScene={setCurrentScene} />
        <Tech setCurrentScene={setCurrentScene} />
        <Works setCurrentScene={setCurrentScene} />
        {/* <Feedbacks /> */}
        <div className='relative z-0'>
          <Contact setCurrentScene={setCurrentScene} />
        </div>

        {/* 🖼️ Shared 3D canvas rendering all scenes */}
        <div className='absolute top-0 left-0 w-full h-full z-[-1]'>
          <SharedCanvas section={currentScene} isMobile={isMobile} />
        </div>
      </div>
    </BrowserRouter>
  );
};

export default App;
